<div class="modal" id="modal"  style="overflow-y: scroll;">
  <div class="bodyModal"> 
  <form method="post" action="" name="form_edit_DJ" id="form_edit_DJ" onsubmit="event.preventDefault();">
    <h1 style="font-family:Arial; font-size: 15pt; color:black"><i class="far fa-id-badge"></i> Edicion de Estado de Nro de Cuenta de Abono</h1> 
    <label>Nombre del Banco</label>
    <input class="cajadetexto" type="text" name="banco" id="banco"  ><br>
    <label>Departamento</label>
    <input class="cajadetexto" type="text" name="departamento" id="departamento"  ><br>
    <label>Provincia</label>
    <input class="cajadetexto" type="text" name="Provincia" id="Provincia"  ><br>
    <label>Distrito</label>
    <input class="cajadetexto" type="text" name="distrito" id="distrito"  ><br> 
    <label>Banco Nacion</label>
    <input class="cajadetexto" type="number"  step='0.01' value='0.00' placeholder='0.00' name="BN" id="BN"  ><br>
    <label>Banco Credito</label>
    <input class="cajadetexto" type="number"  step='0.01' value='0.00' placeholder='0.00' name="BC" id="BC"  ><br>
    <label>BIM</label>
    <input class="cajadetexto" type="number"  step='0.01' value='0.00' placeholder='0.00' name="BM" id="BM"  ><br>
    <label>Caja Piura</label><br>
    <input class="cajadetexto" type="number"  step='0.01' value='0.00' placeholder='0.00' name="CP" id="CP"><br>
    <label>Caja Trujillo</label>
    <input class="cajadetexto" type="number"  step='0.01' value='0.00' placeholder='0.00' name="CT" id="CT"  ><br>
    <label>Cooperativa San Martin</label><br>
    <input class="cajadetexto" type="number"  step='0.01' value='0.00' placeholder='0.00' name="CS" id="CS"><br>
    <label>Efectivo</label>
    <input class="cajadetexto" type="number"  step='0.01' value='0.00' placeholder='0.00' name="EF" id="EF"  ><br>
    <label>Fecha Desembolso</label>
    <input class="cajadetexto" type="date" name="FA" id="FA"  ><br>
    <input id="REG" name="REG" type="hidden" >
    <input id="NOMREGION" name="NOMREGION" type="hidden" >
    <button onclick="editarsocia();" style="margin-top: 25px"><i class="fas fa-save"></i></button>
    <button onclick="cerrarModal()" style="margin-top: 25px"><i class="fas fa-sign-out-alt" ></i></button>
  </form></div>
</div>
<script src="../../dist/js/jsMod/ComportamientoSolicitudes.js?v="<?php echo $_SESSION["Version_cod"]; ?>></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="../../dist/js/adminlte.min.js"></script>
