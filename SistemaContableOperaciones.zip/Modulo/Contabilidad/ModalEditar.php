<div class="modal" id="modal">
  <div class="bodyModal"> 
  <form method="post" action="" name="form_edit_DJ" id="form_edit_DJ" onsubmit="event.preventDefault();">
    <h1 style="font-family:Arial; font-size: 15pt; color:black"><i class="far fa-id-badge"></i> Edicion de Estado de Nro de Cuenta de Abono</h1> 
    <label >Nombre Socia</label><br>
    <input class="cajadetexto" type="text" name="nomsocia" id="nomsocia"  disabled="disabled" ><br>
    <label>Nro Cuenta</label><br>
    <input class="cajadetexto" type="text" name="nrocuenta" id="nrocuenta" disabled="disabled"><br>
    <label>Activo</label><br>
    <input class="cajadetexto" type="text" name="activo" id="activo" required="Campo nesesario" ><br>
    <button onclick="editarsocia();" style="margin-top: 25px"><i class="fas fa-save"></i></button>
    <button onclick="cerrarModal()" style="margin-top: 25px"><i class="fas fa-sign-out-alt" ></i></button>
  </form></div>
</div>
<script src="../../dist/js/jsMod/CuentaAbono.js?v="<?php echo $_SESSION["Version_cod"]; ?>></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>