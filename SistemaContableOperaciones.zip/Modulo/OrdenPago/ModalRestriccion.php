 
<div class="modal" id="modalRestricciones" style="margin-left: 250px">
  <div class="bodyModal"> 
  <form method="post" action="" name="form_edit_DJ" id="form_edit_DJ" onsubmit="event.preventDefault();">
  <h1 style="font-family:Arial; font-size: 15pt; color:red"><i class="fas fa-exclamation-circle"></i>   NO SE PUEDE USAR EL MODULO.</h1> 
  <input id="user" name="user" type="hidden" value="<?php echo $_SESSION['login']; ?>">
  <button id = "botoncerrar" onclick="cerrarModal('#modalRestricciones')" style="margin-top: 25px"><i class="fas fa-sign-out-alt" ></i></button>
  </form></div>
</div>
<script src="../../dist/js/jsMod/ComportamientoOrdenPago.js?v="<?php echo $_SESSION["Version_cod"]; ?>></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
